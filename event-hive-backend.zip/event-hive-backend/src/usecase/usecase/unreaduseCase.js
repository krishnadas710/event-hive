"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.UnreadUseCase = void 0;
class UnreadUseCase {
    constructor(unreadRepository) {
        this.unreadRepository = unreadRepository;
    }
}
exports.UnreadUseCase = UnreadUseCase;
