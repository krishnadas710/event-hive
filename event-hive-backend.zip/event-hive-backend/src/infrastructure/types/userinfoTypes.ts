
export interface IUserInfo {
    name : string,
    userId : string|undefined,
    mobile : string
}