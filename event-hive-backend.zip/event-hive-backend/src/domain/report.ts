export interface IReportItem {
    userEmail: string;
    report: string;
  }
  
  export interface IReport {
    reports: IReportItem[];
  }
  