import { IBookingRepository } from "../../interface/repository/IbookingRepository";

export const paymentConfirmation = async (
    bookingRepository:IBookingRepository,
    transactionId:string,
    bookingid:string,
    user_id:string,
    amount:string
) =>{
    
}