"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.UnreadAdapter = void 0;
class UnreadAdapter {
}
exports.UnreadAdapter = UnreadAdapter;
