import { IRedis } from "../../usecase/interface/services/Iredis";
import { ICompany } from "../../domain/company";
// import { redisClient } from "../config/redis";

 class Redis implements IRedis{
   
    }
   
export default Redis