export interface ISalesReport {
    _id: string;
    user_name: string;
    event_name: string;
    company_name: string;
    booking_date: string;
    payment_status: string;
    payment_amount: string;
    ticket_type: string;
  }