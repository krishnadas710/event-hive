interface Ijwt {
    createJWT(userid : string , email : string , role : string , first_name : string ) : any ;
}

export default Ijwt