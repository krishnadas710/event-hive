"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
// import { redisClient } from "../config/redis";
class Redis {
}
exports.default = Redis;
