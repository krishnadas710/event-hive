export class UnreadAdapter{

}