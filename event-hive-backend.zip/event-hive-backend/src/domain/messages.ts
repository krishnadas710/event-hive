export interface IMessages{
    _id?:string;
    conversationId?:string;
    sender?:string;
    text?:string;
}