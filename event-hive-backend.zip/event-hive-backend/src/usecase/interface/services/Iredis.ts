import { ICompany } from "../../../domain/company";

export interface IRedis {
    
}