"use strict";
// // Import the functions you need from the SDKs you need
// import { initializeApp } from "firebase/app";
// import { getAnalytics } from "firebase/analytics";
// // TODO: Add SDKs for Firebase products that you want to use
// // https://firebase.google.com/docs/web/setup#available-libraries
// // Your web app's Firebase configuration
// // For Firebase JS SDK v7.20.0 and later, measurementId is optional
// const firebaseConfig = {
//   apiKey: "AIzaSyDsrCZE7OvESZq0fBmZ20BB8hxnnHKxDik",
//   authDomain: "event-hive-63ad1.firebaseapp.com",
//   projectId: "event-hive-63ad1",
//   storageBucket: "event-hive-63ad1.appspot.com",
//   messagingSenderId: "517208221052",
//   appId: "1:517208221052:web:f42b61e442ee48befc30f9",
//   measurementId: "G-JLDNQ7TYNL"
// };
// // Initialize Firebase
// const app = initializeApp(firebaseConfig);
// const analytics = getAnalytics(app);
